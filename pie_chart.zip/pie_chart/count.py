import pandas as pd
from collections import Counter

# 从 Excel 文件中读取数据
data = pd.read_excel("./LLM.xlsx")

# 打印数据行数
print("Total number of rows:", len(data))

# 初始化一个列表来存储所有分割后的字符串
result_list = []

# 遍历每一行并检查 'llm' 列是否为空值
for index, row in data.iterrows():
    if not pd.isna(row['llm']):
        # 读取 'llm' 列的内容并根据 '/' 进行切分
        split_values = row['llm'].split('/')
        # 将切分后的结果加入到结果列表中
        result_list.extend(split_values)

# 统计数组中不同值出现的次数
value_counts = Counter(result_list)

# 将统计结果转换为 DataFrame
result_df = pd.DataFrame(value_counts.items(), columns=['llm', 'count'])

# 按出现次数从大到小排序
result_df = result_df.sort_values(by='count', ascending=False)

# 保存结果到 CSV 文件
result_df.to_csv('llm_counts.csv', index=False)

print("Rllm_counts.csv")
